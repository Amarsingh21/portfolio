
function bg() {
  document.body.style.backgroundColor = "#03cffc";
}