$(".rotate").click(function () {
    $(this).toggleClass("down");
})